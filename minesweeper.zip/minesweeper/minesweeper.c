#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define easyLin 9
#define easyCol 9
#define easyMines 10
#define mine '9'

void createEasyBoard(char rootBoard[easyLin][easyCol], char playBoard[easyLin][easyCol]){
    int i, j, k, l;
    int x, y;
    int mineCount;

    for (i=0;i<easyLin;i++){
        for (j=0;j<easyCol;j++){
            rootBoard[i][j] = '0';
            playBoard[i][j] = '#';
        }
    }

    for (i=0;i<easyMines;i){
        x = rand() % easyLin;
        y = rand() % easyCol;

        if (rootBoard[x][y] == '0'){
            rootBoard[x][y] = mine;
            i++;
        }
        else continue;
    }

    for (i=0;i<easyLin;i++){
        for (j=0;j<easyCol;j++){
            if (rootBoard[i][j] == '9')
                continue;

            mineCount = 0;
            for (k=i-1;k!=i+2;k++){
                for (l=j-1;l!=j+2;l++){
                    //printf("%d %d \n", k,l);
                    if (k >= 0 && k <= easyLin && l >= 0 && l <= easyCol){
                        if(rootBoard[k][l] == mine)
                            mineCount++;
                    }
                    else continue;
                }
            }
            rootBoard[i][j] = '0' + mineCount;
        }
    }  
}


void printEasyBoard(char board[easyLin][easyCol]){
    int i, j;
    printf("    0 1 2 3 4 5 6 7 8\n    -----------------\n");
    for (i=0;i<easyLin;i++){
        printf("%d - ", i);
        for (j=0;j<easyCol;j++)
            printf("%c ", board[i][j]);
        
        printf(" - %d\n", i);
    }
    printf("    -----------------\n    0 1 2 3 4 5 6 7 8\n");
}


int main(){
    srand(time(NULL));

    char rootBoard[easyLin][easyCol];
    char playBoard[easyLin][easyCol];

    createEasyBoard(rootBoard, playBoard);
    printEasyBoard(rootBoard);

    printf("\nPress enter to exit...\n");  
    getchar(); 

    return 0;
}